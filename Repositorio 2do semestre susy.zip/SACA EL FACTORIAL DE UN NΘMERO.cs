﻿//ISAAC HARO
//Sacar el factorial de un numero.
//El programa atrapa un número del usuario el mismo que mostrara su factorial.
//Version 1.0
//Fecha de creación: 18/03/2020
//Ultima fecha de actualización: 18/03/2020
using System;
//Nombre del programa
namespace Programa_N_4_P_4_IEHARO
{
    //Clase
    class Program
    {
        //Static
        static void Main(string[] args)
        {
            int n, cont=0, cont1=0,f=1; //Ingreso las variables del numero que se va a ingresar y bucle externo e interno.
            //El programa lee el numero ingresado 
            Console.WriteLine("Ingrese el numero factorial que desea ingresar");
            //El programa guarda el numero ingresado en una variable
            n = int.Parse(Console.ReadLine());
            //El programa imprime antes del bucle el factorial es
            Console.Write("El factorial de " + n+"!");
            while(cont<=n)// numero de vueltas hasta n
            {
                cont1 = 1;//Se pone esto porque multiplicaria por 0 y daria 0
                f = 1;//Se pone esto porque multiplicaria por 0 y daria 0
                while (cont1 <= cont)//Factorial
                {
                    //Programa multiplica f * cont1 para sacar el factorial
                    f = f * cont1;
                   //Contador digue sumando 1 hasta llegar a cont
                    cont1++;   
                }
                cont++;
            }
            //El prigrama imprime la respuesta 
            Console.Write("es " +f);
        }
    }
}
