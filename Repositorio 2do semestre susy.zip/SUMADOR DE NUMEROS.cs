﻿//ISAAC HARO
//Sumatoria de numero si desea sumar si o no
//El programa sumara los numeros ingrasados por el usuario siempre y cuando el mismo apruebe la orden de sumar
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020
//Nos ayuda a tener mas datos
using System;
//Nombre del programa
namespace Programa_N_3_P_3_IEHARO
{
    //clase
	class Program
    {
        //No retorna daros
		static void Main(string[] args)
        {
			//Ingreso mis variables tipo enteros
			int n1 = 0, s = 0;  
			//Ingreso una variable tipo string
			string si_no = "Si"; 
			//Uso un while para la ejecucion del programa
            while (si_no == "Si"|| si_no == "si"|| si_no == "SI"|| si_no == "S")
			{
				//El programa pide que ingrese un numero
				Console.WriteLine("Ingrese un numero");
				//El programa leee el numero y lo guarda en una variable
				n1 = Convert.ToInt32(Console.ReadLine());
				//en otra variable tipo int sigue sumando para completar las sumas
				s = n1 + s;
				//El programa pregunta si desea continuar sumando 
				Console.WriteLine("Desea continuar sumando Si/No");
				//Lee el condicional para que el bucle se siga ejecutando o no
				si_no = Console.ReadLine();

			}
			//Imprime la repyesta de todo el bucle en pantalla
			Console.WriteLine("La sumatoria de los numeros ingresados es: " + s);
        }
    }
}
