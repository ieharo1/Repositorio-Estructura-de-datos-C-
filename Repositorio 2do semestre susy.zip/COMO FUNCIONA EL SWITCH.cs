﻿using System;

namespace Pruebas
{
    class Program
    {
        static void Main(string[] args)
        {
            string palabra, linea2, linea3;
            string letra;
            int res;
            int o = 0;
            int contvo = 0;
            do
            {
                Console.WriteLine("Ingrese un frase");
                palabra = Console.ReadLine();
                Console.WriteLine("Selecione la vocal que desea contabilizar");
                Console.WriteLine("1.  a");
                Console.WriteLine("2.  e");
                Console.WriteLine("3.  i");
                Console.WriteLine("4.  o");
                Console.WriteLine("5.  u");
                linea2 = Console.ReadLine();
                res = int.Parse(linea2);
                switch (res)
                {
                    case 1:
                        Console.WriteLine("Selecciono la vocable a");
                        while (palabra.Length > o)
                        {
                            letra = palabra.Substring(o, 1);
                            if (letra == "a")
                            {
                                contvo++;

                            }
                           o++;
                        }
                        Console.WriteLine("Su palabra tiene la vocal a----------" + contvo);

                        break;
                    case 2:
                        Console.WriteLine("Selecciono la vocable e");
                        while (palabra.Length > o)
                        {
                            letra = palabra.Substring(o, 1);
                            if (letra == "e")
                            {
                                contvo++;

                            }
                            else
                            {
                                Console.WriteLine("Su palabra no tiene la vocal e");

                            }
                            Console.WriteLine("Su palabra tiene la vocal e----------" + contvo);
                            o++;
                        }

                        break;
                    case 3:
                        Console.WriteLine("Selecciono la vocable i");
                        while (palabra.Length > o)
                        {
                            letra = palabra.Substring(o, 1);
                            if (letra == "a")
                            {
                                contvo++;

                            }
                            else
                            {
                                Console.WriteLine("Su palabra no tiene la vocal i");

                            }
                            Console.WriteLine("Su palabra tiene la vocal i----------" + contvo);
                            o++;
                        }

                        break;
                    case 4:
                        Console.WriteLine("Selecciono la vocable o");
                        while (palabra.Length > o)
                        {
                            letra = palabra.Substring(o, 1);
                            if (letra == "o")
                            {
                                contvo++;

                            }
                            else
                            {
                                Console.WriteLine("Su palabra no tiene la vocal o");

                            }
                            Console.WriteLine("Su palabra tiene la vocal o----------" + contvo);
                            o++;
                        }

                        break;
                    case 5:
                        Console.WriteLine("Selecciono la voble u");
                        while (palabra.Length > o)
                        {
                            letra = palabra.Substring(o, 1);
                            if (letra == "u")
                            {
                                contvo++;

                            }
                            else
                            {
                                Console.WriteLine("Su palabra no tiene la vocal u");

                            }
                            Console.WriteLine("Su palabra tiene la vocal u----------" + contvo);
                            o++;
                        }
                        break;

                }
                Console.WriteLine("Desea volver a intentarlo?");
                linea3 = Console.ReadLine();
            } while (linea3 == "si");
        }
    }
}
