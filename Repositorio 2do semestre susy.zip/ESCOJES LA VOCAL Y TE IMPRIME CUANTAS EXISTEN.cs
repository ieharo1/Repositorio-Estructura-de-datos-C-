﻿using System;
namespace Programa_1
{
    class PROGRAMA_1
    {
        static void Main(string[] args)
        {
            string whil = "si";//Ingreso una variable para que ingrese al while
            while (whil == "si" || whil == "SI" || whil == "Si" || whil == "sI" || whil == "S")//Condiciones para que se siga ejecutando el programa
            {
                int cont = 0, cont2 = 0, abcd = 0;//Definir las variables tipo int
                string voca = "a", voce = "e", voci = "i", voco = "o", vocu = "u", m, a;//Definir las variables tipo string
                Console.WriteLine("Ingresa tu oracion o frase"); m = Console.ReadLine().ToLower();// Ingresa la oración, lee la oración ingresada y la transforma todo a minusculas 
                Console.WriteLine("Escoja la vocal que deseas que se contabilice de entre todas las opciones");//Imprime en pantalla las opciones para que escoja
                Console.WriteLine("a"); Console.WriteLine("e"); Console.WriteLine("i"); Console.WriteLine("o"); Console.WriteLine("u"); Console.WriteLine("Cualquier otro dato ingresado no sera valido");//escoje una de las opciones
                a = Console.ReadLine().ToLower();//Lee las opciones y la transforma a minusculas
                while (cont2 < m.Length)//Si contador es menor que la longitud del texto ingresa al while
                {
                    cont = 0;//contador es igual a 0
                    while (cont < voca.Length || cont < voce.Length || cont < voci.Length || cont < voco.Length || cont < vocu.Length)//Si contador es menor que la longitud de la vocal a ser analizada ingresa al while
                    {
                        if (a == "a" || a == "e" | a == "i" | a == "o" || a == "u")//Si la vocal ingresada es igual a la variable a podrá ingresar a las opciones establecidas por el usuario
                        {
                            if (a == "a" && voca.Substring(cont, 1)  == m.Substring(cont2, 1))//Si quiere ver cuanta vocales a existen en el texto y hay vocales a en el texto ingresara al if
                            {
                                abcd++;//Contador del numero de vocales
                            }
                            else if (a == "e" && voce.Substring(cont, 1) == m.Substring(cont2, 1))//Si quiere ver cuanta vocales e existen en el texto y hay vocales a en el texto ingresara al else if
                            {
                                abcd++;//Contador del numero de vocales
                            }
                            else if (a == "i" && voci.Substring(cont, 1) == m.Substring(cont2, 1))//Si quiere ver cuanta vocales i existen en el texto y hay vocales a en el texto ingresara al else if
                            {
                                abcd++;//Contador del numero de vocales
                            }
                            else if (a == "o" && voco.Substring(cont, 1) == m.Substring(cont2, 1))//Si quiere ver cuanta vocales o existen en el texto y hay vocales a en el texto ingresara al else if
                            {
                                abcd++;//Contador del numero de vocales
                            }
                            else if (a == "u" && vocu.Substring(cont, 1) == m.Substring(cont2, 1))//Si quiere ver cuanta vocales u existen en el texto y hay vocales a en el texto ingresara al else if
                            {
                                abcd++;//Contador del numero de vocales
                            }
                            cont++; cont2++;//Aumenta de uno en uno los contadores 
                        }
                        else//Caso contrario se guardara el abcd como 0
                        {
                            abcd = 0;
                        }
                    }
                }
                if (abcd >= 1)//Si el contador abcd es mayor o igual a 1 imprimira en pantalla
                {
                    Console.WriteLine("La palabra tiene " + abcd + " vocales " + a);//Imprime en pantalla el numero de vocales que tiene el texto ingresado y la vocal que se busco
                }
                else//Caso contrario imprimira en pantalla
                {
                    Console.WriteLine("El texto ingresado no contiene la vocal seleccionada");//Imprime en pantalla que el texto no contiene la vocal seleccionada
                }
                Console.WriteLine("¿Desea volver a ejecutar el programa");//Ingresa "si" si quiere volver a ejecutar 
                whil = Console.ReadLine();//Lee como un tipo string 
            }
        }
    }
}