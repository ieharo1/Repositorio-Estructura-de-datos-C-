﻿//ISAAC HARO
//Tabla de multiplicar 10*10 con los primeros digitos ingresados
//Tabla (10 x 10), que permite al usuario indicar el valor donde comienzan los multiplicadores (filas) y los multiplicandos (columnas). 
//Version 1.0
//Fecha de creación 21/03/2020
//Ultima fecha de actualizacion 21/03/2020
using System;
//Nombre del programa
namespace Programa_N_1_P_4
{
    //Clase del programa
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            int p, q, y, z, m, auxq,rest;//INGRESO DE LAS VARIABLES
            Console.WriteLine("Ingrese el primer número que desea multiplicar(multiplicadores)");//El programa pide que ingrese los multiplicadores (filas)
            p = int.Parse(Console.ReadLine());//El programa lee como int
            Console.WriteLine("Ingrese el segundo número que desea multiplicar(multiplicandos)");//El programa pide que ingrese los  multiplicandos (columnas). 
            q = int.Parse(Console.ReadLine());//El programa lee como int
            y = p + 9;//Es hasta donde se multiplicara en las filas
            z = q + 10;//Es hasta donde se multiplicara en las columnas
            auxq = q * 1;//Auxiliar
            rest = q;//Resto
            Console.Write("|" + " " + "|");//Escribira el primer espacio para que se pueda generar una matriz de multiplicacion
            while (auxq <= z)//While para los numeros que estan dentro del límite establecido 
            {
                Console.Write("|" + auxq + "|");//La conosola escribira las respuestas en pantalla
                auxq++;//Va aumentando 1
            }
            Console.WriteLine();//Deja un espacion en blanco
            Console.Write("|" + p + "|");//Escribe en el espacio en blanco 
            while (p <= y)//While para los numeros que estan dentro del límite establecido
            {
                    while (q <= z)//While para los numeros que estan dentro del límite establecido
                    {
                        m = p * q;//Multiplica los numeros
                        Console.Write("|" + m + "|");//Imprime las respuestas
                        q++;//Va sumando 1
                    }
                    q=rest;//Se restablece q
                Console.WriteLine();//Deja un espacio en blanco
                p++;//Va sumando 1
                Console.Write("|" + p + "|");//Imprime las filas
            }
            while (q <= z)//While para los numeros que estan dentro del límite establecido
            {
                m = p * q;//Multiplica 
                Console.Write("|" + m + "|");//Imprime las respuestas
                q++;//Va sumando 1
            }
        }
    }
}