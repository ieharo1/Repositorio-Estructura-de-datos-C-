﻿using System;

namespace Programa2
{
    class Programa_N_2
    {
        static void Main(string[] args)
        {
            string whil = "si";//Ingreso una variable para que ingrese al while
            while (whil == "si" || whil == "SI" || whil == "Si" || whil == "sI" || whil == "S")//Condiciones para que se siga ejecutando el programa
            {
                string cad,cad2,cad3="",aux;//Definición de variables
            int i = 0;//Definición de variables
            Console.WriteLine("Ingrese un Palíndromo");//El programa pide que Ingrese un palíndromo
            cad = Console.ReadLine().ToLower();//Lee y transforma todo a mínusculas
            cad = cad.Replace(" ", "").Replace("á", "a").Replace("é", "e");//reemplaza las tildes de las vocales por vocales 
            cad = cad.Replace("í", "i").Replace("ó", "o").Replace("ú", "u");//reemplaza las tildes de las vocales por vocales
            cad2 = cad;//Guarda el dato ingresado en una variable 
            while (i<cad2.Length)//Si i es menor que la Longitud ingresa al while
            {
                aux=cad.Substring(cad.Length-i-1,1);//Da la vuelta a la frase ingresada
                cad3 = cad3 + aux;//Va guardando la frase
                i++;//Aumenta de 1 en 1 la variable i
            }
            if (cad3 == cad2)//Verifica si las 2 son iguales
            {
                Console.WriteLine("Es palindromo");//Imprime en pantalla es palíndromo
            }
            else
            {
                Console.WriteLine("No es palindromo");//Imprime en pantalla no es palíndromo
            }
                Console.WriteLine("¿Desea volver a ejecutar el programa");//Ingresa "si" si quiere volver a ejecutar 
                whil = Console.ReadLine();//Lee como un tipo string 
            }
        }
    }
}
 