﻿//ISAAC HARO
//Tabla tipo matriz
//Imprime una tabla tipo matriz desde 1 a 3 en filas y desde 1 a 4 en columnas
//Version 1.0
//Fecha de creación 21/03/2020
//Ultima fecha de actualizacion 21/03/2020
using System;
//Nombre del programa
namespace Programa_N_1_P_4
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            //Variables
            int p=1, q=1;
            //While
            while (p <= 3)
            {
                //While
                while (q <= 4)
                {
                   //La consola imprime la columna de la matriz
                    Console.Write("|" + p + "-" + q + "|" + "");
                    //La consola sigue aumentando 1 
                    q++;
                }
                //Salta una linea para generar la siguiente columna de la matriz
                Console.WriteLine();
                //q retorna a 1 para que siga funcionando el While
                q = 1;
                //P sigue aumentando 1 
                p++;
            }
        }
    }
}
