﻿using System;

namespace Arregloclase
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string[] cars = new string[4] { "Volvo", "BMW", "Ford", "Mazda" };
            int i = cars.Length - 1;
            while (i>=0)
            {
                Console.WriteLine(cars[i]);
                i--;
            }
        }
    }
}
