﻿//Isaac Haro
//Numero de estudiantes en ingenieria
//Programa a prueba de errors que permite ingresar el numero de estudiantes de ingenieria y saca el porcentaje de estudiantes por carrera
//Fecha 25/03/2020
//Version 1.0
//Ultima fecha de modificacion 27/03/2020
using System;

namespace Programa_N_P_5
{
    class Program
    {
        static void Main(string[] args)
        {
            UInt32 a;//Para comprobar numeros mayores de 0
            string quiere="si",numcivil, numcompu, numinfo, numtecno;//Ingreso mis variables tipo string
            bool comp;//Ingreso las variables tipo bool
            int no1,no2,no3,no4;//Ingreso las variables tipo int
            double not1, not2, not3, not4, suma;//Ingreso de las variables tipo double
            while (quiere == "si")//Bucle while
            {
                /*                                                                                              Civil                            */
                Console.WriteLine("Ingrese el numero de estudiantes de Ingeniería Civil");
                numcivil = Console.ReadLine();//Lee como string
                if (UInt32.TryParse(numcivil, out a))//Comprueba si es un numero y si es mayor igual que 0
                {
                    Console.WriteLine("Número valido");//Lee como numero valido
                }
                else//Caso contrario pedira que ingrese un numero valido
                {
                    Console.WriteLine("Ingrese nuevamente el numero de estudiantes");//Pide que ingrese de nuevo el numero de estudiantes
                    numcivil = Console.ReadLine();//Lee el numero de estudiantes
                    comp = UInt32.TryParse(numcivil, out a);//Comprueba de nuevo si es numero y mayor igual que 0
                    while (comp == false)// si es falso nuevamente pide que ingrese un numero mayor igual que 0
                    {
                        Console.WriteLine("Ingrese nuevamente el numero de estudiantes");
                        numcivil = Console.ReadLine();
                        comp = UInt32.TryParse(numcivil, out a);
                    }
                }
                int doble1 = Int32.Parse(numcivil);//Convierte el string a int
                no1 = doble1 * 1;//Lo guarda como int
                /*                                                                                           Sistemas y Computacion              */
                Console.WriteLine("Ingrese el numero de estudiantes de Ingeniería de Sistemas y Computación");
                numcompu = Console.ReadLine();//Lee como string
                if (UInt32.TryParse(numcompu, out a))//Comprueba si es un numero y si es mayor igual que 0
                {
                    Console.WriteLine("Número valido");//Lee como numero valido
                }
                else//Caso contrario pedira que ingrese un numero valido
                {
                    Console.WriteLine("Ingrese nuevamente el numero de estudiantes");//Pide que ingrese de nuevo el numero de estudiantes
                    numcompu = Console.ReadLine();//Lee el numero de estudiantes
                    comp = UInt32.TryParse(numcompu, out a);//Comprueba de nuevo si es numero y mayor igual que 0
                    while (comp == false)// si es falso nuevamente pide que ingrese un numero mayor igual que 0
                    {
                        Console.WriteLine("Ingrese nuevamente el numero de estudiantes");
                        numcompu = Console.ReadLine();
                        comp = UInt32.TryParse(numcompu, out a);
                    }
                }
                int doble2 = Int32.Parse(numcompu);//Convierte el string a int
                no2 = doble2 * 1;//Lo guarda como int
                /*                                                                                            Ingeniería de Sistemas de Información           */
                Console.WriteLine("Ingrese el numero de estudiantes de Ingeniería de Sistemas de Información");
                numinfo = Console.ReadLine();//Lee como string
                if (UInt32.TryParse(numinfo, out a))//Comprueba si es un numero y si es mayor igual que 0
                {
                    Console.WriteLine("Número valido");//Lee como numero valido
                }
                else//Caso contrario pedira que ingrese un numero valido
                {
                    Console.WriteLine("Ingrese nuevamente el numero de estudiantes");//Pide que ingrese de nuevo el numero de estudiantes
                    numinfo = Console.ReadLine();//Lee el numero de estudiantes
                    comp = UInt32.TryParse(numinfo, out a);//Comprueba de nuevo si es numero y mayor igual que 0
                    while (comp == false)// si es falso nuevamente pide que ingrese un numero mayor igual que 0
                    {
                        Console.WriteLine("Ingrese nuevamente el numero de estudiantes");
                        numinfo = Console.ReadLine();
                        comp = UInt32.TryParse(numinfo, out a);
                    }
                }
                int doble3 = Int32.Parse(numinfo);//Convierte el string a int
                no3 = doble3 * 1;//Lo guarda como int
                /*                                                                                             Ingeniería de Tecnologías de la Información         */
                Console.WriteLine("Ingrese el numero de estudiantes de Ingeniería de Tecnologías de la Información");
                numtecno = Console.ReadLine();//Lee como string
                if (UInt32.TryParse(numtecno, out a))//Comprueba si es un numero y si es mayor igual que 0
                {
                    Console.WriteLine("Número valido");//Lee como numero valido
                }
                else//Caso contrario pedira que ingrese un numero valido
                {
                    Console.WriteLine("Ingrese nuevamente el numero de estudiantes");//Pide que ingrese de nuevo el numero de estudiantes
                    numtecno = Console.ReadLine();//Lee el numero de estudiantes
                    comp = UInt32.TryParse(numtecno, out a);//Comprueba de nuevo si es numero y mayor igual que 0
                    while (comp == false)// si es falso nuevamente pide que ingrese un numero mayor igual que 0
                    {
                        Console.WriteLine("Ingrese nuevamente el numero de estudiantes");
                        numtecno = Console.ReadLine();
                        comp = UInt32.TryParse(numtecno, out a);
                    }
                }
                int doble4 = Int32.Parse(numtecno);//Convierte el string a int
                no4 = doble4 * 1;//Lo guarda como int
                suma = no1+ no2+ no3+ no4;//Suma todos los resultados y los guarda como double
                not1 = no1 / suma * 100;//Reliza la operacion para sacar el porcentaje y esto es posible solo con variables tipo double
                not2 = no2 / suma * 100;//Reliza la operacion para sacar el porcentaje y esto es posible solo con variables tipo double
                not3 = no3 / suma * 100;//Reliza la operacion para sacar el porcentaje y esto es posible solo con variables tipo double
                not4 = no4 / suma * 100;//Reliza la operacion para sacar el porcentaje y esto es posible solo con variables tipo double
                Console.WriteLine( "Ingenieria Civil tiene " + numcivil + " estudiantes que son "+ Math.Round(not1, 3) + "%");//Imprime en pantalla la respuesta y el porcentaje con solo 3 decimales
                Console.WriteLine("Ingenieria Civil tiene " + numcompu + " estudiantes que son "+Math.Round(not2, 3) + "%");//Imprime en pantalla la respuesta y el porcentaje con solo 3 decimales
                Console.WriteLine("Ingeniería de Sistemas de Información  tiene " + numinfo + " estudiantes que son "+ Math.Round(not3, 3) + "%");//Imprime en pantalla la respuesta y el porcentaje con solo 3 decimales
                Console.WriteLine("Ingeniería de Tecnologías de la Información   tiene " + numtecno + " estudiantes que son "+ Math.Round(not4, 3) + "%");//Imprime en pantalla la respuesta y el porcentaje con solo 3 decimales
                Console.WriteLine("Quiere seguir ingresando datos");//Pregunta si desea seguir
                quiere = Console.ReadLine();//Lee como string
            }
        }
    }
}
