﻿using System;
namespace PROGRAMA_1_PRACTICA_7_IEHARO
{
    class Program
    {
        static void Main(string[] args)
        {
            string seguir="Si";
            while (seguir=="Si"||seguir=="SI" || seguir == "si" || seguir == "sI" || seguir == "S" || seguir == "s") 
            {
                string[] cadena;
                int j = 0,cuantas;
                string mas, menos, numeros = "1234567890", cuanta;
                bool finprograma = false, confirma=false;
                Console.WriteLine("Ingrese el número de cadenas que desee");
                cuanta = Console.ReadLine();
                while (confirma==false) 
                {
                    if (numeros.Contains(cuanta))
                    {
                        cuantas = int.Parse(cuanta);
                        confirma = true;
                        if (cuantas == 0)
                        {
                            finprograma = true;
                            Console.WriteLine("Fin del programa");
                        }
                        else
                        {
                            finprograma = false;
                        }
                        if (finprograma == false)
                        {

                            while (cuantas < 0)
                            {
                                Console.WriteLine("Ingrese el número de cadenas que desee que sea positivo");
                                cuantas = int.Parse(Console.ReadLine());
                            }
                            cadena = new string[cuantas];
                            while (cadena.Length > j)
                            {
                                Console.WriteLine("Cadena" + (j + 1));
                                Console.WriteLine("Ingrese la frase que será analizada");
                                cadena[j] = Console.ReadLine();
                                while (numeros.Contains(cadena[j]))
                                {
                                    Console.WriteLine("La frase ingresada no puede contener números, ingrese una frase valida");
                                    cadena[j] = Console.ReadLine();
                                }
                                j++;
                            }
                            j = 0;
                            mas = cadena[0];
                            menos = cadena[0];
                            while (cadena.Length > j + 1)
                            {
                                if (mas.Length < cadena[j + 1].Length)
                                {
                                    mas = cadena[j + 1];
                                }
                                if (menos.Length > cadena[j + 1].Length)
                                {
                                    menos = cadena[j + 1];
                                }
                                j++;
                            }
                            Console.WriteLine("La cadena mayor es: cadena " + mas + " y la cadena menor es: cadena " + menos);
                        }
                    }
                    else
                    {
                        Console.WriteLine("No se pueden ingrasar caracteres tipo albafetico o signos");
                        Console.WriteLine("Ingrese el número de cadenas que desee");
                        cuanta = Console.ReadLine();
                        confirma = false;
                    }
                }
                Console.WriteLine("Quiere repetir el programa");
                seguir = Console.ReadLine();
            }
        }
    }
}
