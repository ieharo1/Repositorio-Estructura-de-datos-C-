﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Da la ubicación de un número
            int[] numeros = { 5, 6, 7, 3, 2, 5, 9, 5, 6, 3 };
            int i = 0, numero;
            string aux="";
            Console.WriteLine("Que numero desea adivinar");
            numero = int.Parse(Console.ReadLine());
            while (i < numeros.Length)
            {
                if (numeros[i] == numero) 
                { 
                    
                    aux=(aux+i)+"";
                    
                }
                i++;
            }
            Console.WriteLine("La ubicacion es"+aux);
        }
    }
}
