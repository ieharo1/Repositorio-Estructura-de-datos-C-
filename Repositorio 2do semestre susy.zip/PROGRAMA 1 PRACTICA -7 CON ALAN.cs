﻿using System;

namespace P7_Programa1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cad;
            int x,i=0;
            string mayor, menor;

            Console.WriteLine("¿Cuántas cadenas desea ingresar?");
            x = int.Parse(Console.ReadLine());
            cad = new string[x];

            while (i<cad.Length) {
                Console.WriteLine("Ingrese la cadena número "+(i+1));
                cad[i] = Console.ReadLine();
                i++;
            }
            i = 1;
            mayor = cad[0];
            menor = cad[0];
            while (i < cad.Length)
            {
                if (mayor.Length < cad[i].Length)
                {
                    mayor = cad[i];
                }
                if(menor.Length > cad[i].Length)
                {
                    menor = cad[i];
                }
                i++;
            }
            Console.WriteLine("La cad mayor es: cad "+mayor+ " y la cad menor es: cad "+menor);
        }
    }
}
