﻿//ISAAC HARO
//Reverso de un numero
//El programa escribe un numero ingresado al reves
//Version 1.0
//Fecha de creación 11/03/2020
//Ultima fecha de actualizacion 11/03/2020
//Nos ayuda a tener mas datos
using System;
//Nombre del Programa
namespace Programa_N_2_P_3
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            //Ingreso de una variable int
            int n, aux;
            //Programa pide ingrese un numero
            Console.WriteLine("Ingrese un numero");
            //Lee como variable n
            n = int.Parse(Console.ReadLine());
            //Escribe el resultado del inverso
            Console.Write("El inverso del numero ingresado es  ");
            //Funcion do while
            do
            {
                //Saca el residuo de el numero para 10
                aux = n % 10;
                //Divide para 10 hasta llegar a 0
                n = n / 10;
                //Escribe el resultado junto
                Console.Write(aux);
              //Si llega a 0 fin del bucle
            } while (n > 0);
            {
                

            }
        }
    }
}
