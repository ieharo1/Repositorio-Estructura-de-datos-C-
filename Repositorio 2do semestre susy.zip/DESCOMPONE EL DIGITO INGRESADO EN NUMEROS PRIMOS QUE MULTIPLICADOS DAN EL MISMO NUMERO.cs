﻿//ISAAC HARO
//Halla numeros primos
//El programa lo que hace es analizar el digito ingresado para que el mismo se descomponga en numeros primos que multiplicados dan el mismo digito ingresado
//Version 1.0
//Fecha de creación 02/03/2020
//Ultima fecha de actualizacion 02/03/2020
using System;
//Nombre del programa
namespace Programa_N_5_P_3_IEHARO
{
    //Clase
    class Program
    {
       //No retorna datos
        static void Main(string[] args)
        {
           //Ingreso de los valores int
            int x, w = 2;
           //Escribe ingrese un numero
            Console.WriteLine(" Ingrese un numero");
            //Lee como entero
            x = int.Parse(Console.ReadLine());
            //Imprime en pantalla los numeros primos son
            Console.Write("Los numeros primos del numero son"+ "");
            //Uso una condicion while para que haga este proceso hasta que sea igual a 0
            while (x > 1)
            {
                //Uso un condicional if
                if (x%w==0)
                {
                    //El programa imprime en pantalla las respuestas
                    Console.Write(w + "*" +"");
                    //El programa divide por el numero al que se lo dividio anteriormente y lo guarda para completar el bucle
                    x = x / w;
                }
                //Uso un condicional else if
                else if(x%w != 0)
                {
                   //Suma 1 a w porque con 2 no sirvio hasta conseguir lo que se desea
                    w = w + 1;
                }

            }
        }
    }
}
