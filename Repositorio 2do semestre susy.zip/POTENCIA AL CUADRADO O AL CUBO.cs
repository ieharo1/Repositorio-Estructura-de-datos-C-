﻿//ISAAC HARO
//Sacar el cuadrado y el cubo de un número x.
//El programa atrapa un número del usuario el mismo que mostrara su potencia al cuadrado o al cubo.
//Version 1.0
//Fecha de creación: 26/02/2020
//Ultima fecha de actualización: 26/02/2020

//Nos ayuda a tener datos para soluciones Matemáticas
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TITULO_PARA_DEBERES
{
    class Cuadrado_Cubo
    {
        static void Main(string[] args)
        {
            //Ingreso mis enteros
            int numro = 0, cubo = 3, i, ayud1 = 0, ayud2 = 1;
            //Ingreso mis variables
            string exill;
            //Ingreso del numero x que se desea hallar
            Console.WriteLine("Ingrese el dígito que desee para hallar su cuadrado y cubo");
            //Leo el dato ingresado
            exill = Console.ReadLine();
            //Cambio el tipo de dato a entero
            numro = int.Parse(exill);
            //Usamos una funcion para
            for (i = 1; i <= numro; i++)// En pasos de uno sacar el numero
            {
                ayud1 = ayud1 + numro;
            }
            //Usamsos otra funcion logica para sacar el cubo ya que la anterior era para sacar el cuadrado
            for (i = 1; i <= cubo; i++)// En pasos de uno sacar el numero
            {
                ayud2 = ayud2*numro;
            }
            //Imprimo las respuestas en pantalla
            Console.Write("El valor de " + numro + "  al cuadrado es  " + ayud1 +"  y este digito elevado al cubo es  " +ayud2 );
            Console.ReadKey();
            Console.WriteLine();
        }
    }
}
