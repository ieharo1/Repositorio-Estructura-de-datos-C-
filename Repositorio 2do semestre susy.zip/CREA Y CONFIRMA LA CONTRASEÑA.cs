﻿//ISAAC HARO
//Creador de contraseñas
//Crea un contrasela de 4 digitos en el programa y verifica si es la misma contraseña o no
//Version 1.0
//Fecha de creación 13/03/2020
using System;
//Nombre del programa
namespace Programa_N_4_P_3
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            int a = 0;

            int i = 2;

            do

            {

                Console.WriteLine(i * a);

                a = a + 1;

            }

            while (a < 10);

            Console.ReadLine();
        }
        
    }
}
