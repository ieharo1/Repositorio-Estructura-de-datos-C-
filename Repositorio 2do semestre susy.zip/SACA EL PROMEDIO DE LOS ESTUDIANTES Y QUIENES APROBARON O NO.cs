﻿//ISAAC HARO
//Ingreso de notas
//Programa que ingresa las notas de los estudiante sobre 10, saca el promedio y si aprobo 
//Version 1.0
//Fecha de creación 27/03/2020
//Ultima fecha de actualizacion 27/03/2020
using System;
//NOMBRE DEL PROGRAMA
namespace programa_2
{
    class Program//CLASE
    {
        static void Main(string[] args)//NO RETORNA DATOS
        {
            string not1, not2, not3, not4, whil;//Ingreso de la variable tipo string
            UInt32 a;//Entero sin signo con valores mayores a 0
            Double d,no1,no2,no3,no4, sumatoria ,promedio;//Ingreso de la variable tipo double
            whil = "si";//Inicializacion del while
            while (whil == "si" || whil == "SI" || whil == "Si" || whil == "sI" || whil == "S")//Uso de while
            {
                Console.WriteLine("Ingrese la primera nota");//Consola pide el ingreso de datos
                not1 = Console.ReadLine();//Se la lee como un tipo string
                if (UInt32.TryParse(not1, out a))//Verifica si es un número entero positivo
                {
                    double doble1 = Double.Parse(not1);//Convierte el string a double
                    no1 = doble1 * 1.00;//Lo guarda como double
                }
                else if (Double.TryParse(not1, out d))//Verifica si es un número double
                {
                    double doble1 = Double.Parse(not1);//Convierte el string a double
                    no1 = doble1 * 1;//Lo guarda como double
                }
                else//Sino cumple ninguna de las condiciones imprime que la nota no es valida
                {
                    no1 = -1;//Guarda a la variable tipo string como -1 para que no se saque el promedio
                    Console.WriteLine("Nota ingresada fuera del rango 0 y 10");
                }
                Console.WriteLine("Ingrese la segunda nota");//Consola pide el ingreso de datos
                not2 = Console.ReadLine();//Se la lee como un tipo string
                if (UInt32.TryParse(not2, out a))//Verifica si es un número entero positivo
                {
                    double doble2 = Double.Parse(not2);//Convierte el string a double
                    no2 = doble2 * 1.00;//Lo guarda como double
                }
                else if (Double.TryParse(not2, out d))//Verifica si es un número double
                {
                    double doble2 = Double.Parse(not2);//Convierte el string a double
                    no2 = doble2 * 1;//Lo guarda como double
                }
                else//Sino cumple ninguna de las condiciones imprime que la nota no es valida
                {
                    no2 = -1;//Guarda a la variable tipo string como -1 para que no se saque el promedio
                    Console.WriteLine("Nota ingresada fuera del rango 0 y 10");
                }
                Console.WriteLine("Ingrese la tercera nota");//Consola pide el ingreso de datos
                not3 = Console.ReadLine();//Se la lee como un tipo string
                if (UInt32.TryParse(not3, out a))//Verifica si es un número entero positivo
                {
                    double doble3 = Double.Parse(not3);//Convierte el string a double
                    no3 = doble3 * 1.00;//Lo guarda como double
                }
                else if (Double.TryParse(not3, out d))//Verifica si es un número double
                {
                    double doble3 = Double.Parse(not3);//Convierte el string a double
                    no3 = doble3 * 1;//Lo guarda como double
                }
                else//Sino cumple ninguna de las condiciones imprime que la nota no es valida
                {
                    no3 = -1;//Guarda a la variable tipo string como -1 para que no se saque el promedio
                    Console.WriteLine("Nota ingresada fuera del rango 0 y 10");
                }
                Console.WriteLine("Ingrese la cuarta nota");//Consola pide el ingreso de datos
                not4 = Console.ReadLine();//Se la lee como un tipo string
                if (UInt32.TryParse(not4, out a))//Verifica si es un número entero positivo
                {
                    double doble4 = Double.Parse(not4);//Convierte el string a double
                    no4 = doble4 * 1.00;//Lo guarda como double
                }
                else if (Double.TryParse(not4, out d))//Verifica si es un número double
                {
                    double doble4 = Double.Parse(not4);//Convierte el string a double
                    no4 = doble4 * 1;//Lo guarda como double
                }
                else//Sino cumple ninguna de las condiciones imprime que la nota no es valida
                {
                    no4 = -1;//Guarda a la variable tipo string como -1 para que no se saque el promedio
                    Console.WriteLine("Nota ingresada fuera del rango 0 y 10");
                }
                //Promedio
                if (no1 >= 0 && no2 >= 0 && no3 >= 0 && no4 >= 0&&no1 <= 10 && no2 <= 10 && no3 <= 10 && no4 <= 10)
                {
                    sumatoria = no1 + no2 + no3 + no4;//Suma todos los datos ingresados
                    promedio = sumatoria / 4;//Saca el promedio de los datos ingresados
                    if (promedio > 6)//Si el promedio es mayor a 6 aprobara
                    {
                        Console.WriteLine("Aprobo el año con el promedio de " + promedio);
                    }
                    else if (promedio <= 6)//Si el promedio es menor igual a 6 reprobara
                    {
                        Console.WriteLine("Reprobo el año con el promedio de " + promedio);
                    }
                    else//Si no se puede determinar se escribira un error
                    {
                        Console.WriteLine("No se pudo determinar el promedio. Las notas deben estar entre 0 y 10.");
                    }
                }
                else//Sino cumple no se podra determinar
                {
                    Console.WriteLine("No se pudo determinar el promedio. Las notas deben estar entre 0 y 10.");
                }
                Console.WriteLine("¿Desea ingresar nuevamente las calificaciones ");//Ingresa si quiere las calificaiones nuevamente
                whil = Console.ReadLine();//Lee como un tipo string
            }
        }
    }
}
