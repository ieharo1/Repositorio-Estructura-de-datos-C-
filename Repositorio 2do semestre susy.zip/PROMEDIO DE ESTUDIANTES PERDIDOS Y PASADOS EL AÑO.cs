﻿//ISAAC HARO
//Sacar las notas.
//El programa atrapa un número del usuario el mismo que mostrara el promedio del numero de estudiantes, el numero de estudiantes perdidos y pasados el año.
//Version 1.0
//Fecha de creación: 18/03/2020
//Ultima fecha de actualización: 18/03/2020
using System;
//Nombre del programa
namespace Programa_N_3_P_4_IEHARO
{
    //Clase
    class Program
    {
        //No retorna datos
        static void Main(string[] args)
        {
            //Ingreso de las variables
            int nota, n, cont = 1, p=0, perdidos=0, aprobados, prome;
            //Consola pide el numero de estudiantes
            Console.WriteLine("Ingrese el numero de estudiantes");
            //Consola lee el numero de estudiantes
            n = int.Parse(Console.ReadLine());
            //Uso de while 
            while(cont<=n)
            {
                //Consola pide la nota de cada estudiante
                Console.WriteLine("Ingresar la nota del estudiante");
                //Consola lee la nota
                nota = int.Parse(Console.ReadLine());
                //El promedio sigue sumando las notas
                p = p + nota;
                //Uso del if para verificar quiene pasaron y quienes se quedaron
                if(nota<30)
                {
                    //Los perdidos se siguen sumando
                    perdidos++;
                }
                //Cont sigue sumando
                cont++;

            }
            //Aprobados
            aprobados = n - perdidos;
            //Promedios
            prome = p / n;
            //Consola escribe el promedio 
            Console.WriteLine("El promedio es " +prome );
            //Consola escribe el numero de perdidas de semestre
            Console.WriteLine("El numero de estudiantes perdidos el semestre es " +perdidos);
            //Consola escribe el numero de aprobadas de semestre
            Console.WriteLine("El numero de estudiantes aprobados es" +aprobados);
        }
    }
}
